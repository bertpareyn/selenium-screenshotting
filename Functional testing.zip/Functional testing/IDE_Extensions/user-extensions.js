Selenium.prototype.doTakeScreenshot = function(locator){
    /**
     * Tells the java back-end to take a screenshot of the full web page
     * Doesn't work in javascript so it is a java function only
     */
    
};