CommandBuilders.add("action", function(window){
    return {
        command:"takeScreenshot",
        disabled: false
    };
});