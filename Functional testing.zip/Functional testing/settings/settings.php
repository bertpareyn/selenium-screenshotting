<?php header('Content-type: application/json'); ?>
{
    "server" : "http://10.0.0.86:8888/",
    "proxy" : "proxy/",
    "dbaccess" : "polling/"
}